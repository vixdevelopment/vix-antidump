local function log(msg)
  print((Config.LogPrefix or '[AntiDump]') .. ' ' .. msg)
end

local function extractIdentifiers(src)
  local ids = {
    steam = nil,
    license = nil,
    license2 = nil,
    discord = nil,
    xbl = nil,
    live = nil,
    fivem = nil,
    ip = GetPlayerEndpoint(src) or 'unknown',
    name = GetPlayerName(src) or ('Player ' .. tostring(src))
  }
  for _, id in ipairs(GetPlayerIdentifiers(src)) do
    if id:find('steam:') == 1 then ids.steam = id
    elseif id:find('license:') == 1 then ids.license = id
    elseif id:find('license2:') == 1 then ids.license2 = id
    elseif id:find('discord:') == 1 then ids.discord = id
    elseif id:find('xbl:') == 1 then ids.xbl = id
    elseif id:find('live:') == 1 then ids.live = id
    elseif id:find('fivem:') == 1 then ids.fivem = id
    end
  end
  return ids
end

local function sendDiscord(payload)
  if not Config.DiscordWebhook or Config.DiscordWebhook == '' then return end
  PerformHttpRequest(Config.DiscordWebhook, function() end, 'POST', json.encode(payload), { ['Content-Type'] = 'application/json' })
end

RegisterNetEvent('antidump:detected')
AddEventHandler('antidump:detected', function(data)
  local src = source
  local ids = extractIdentifiers(src)

  local reason = (data and data.reason) or 'unknown'
  local extra = (data and data.extra) or {}
  local stack = (data and data.stack) or 'n/a'
  local res = (data and data.resource) or 'n/a'

  log(('Detection from %s (%s) | IP %s | Reason: %s | Res: %s'):format(ids.name, ids.steam or ids.license or 'noid', ids.ip, reason, res))
  log(('Stack: %s'):format(stack))

  -- Send webhook if configured
  sendDiscord({
    username = 'AntiDump',
    embeds = {
      {
        title = 'Anti-Dump Detection',
        color = 15158332,
        description = ('Player: %s\nIP: %s\nReason: %s\nResource: %s\nStack: %s'):format(ids.name, ids.ip, reason, res, stack),
        fields = {
          { name = 'Steam', value = ids.steam or 'n/a', inline = true },
          { name = 'License', value = ids.license or 'n/a', inline = true },
          { name = 'Discord', value = ids.discord or 'n/a', inline = true },
          { name = 'FiveM', value = ids.fivem or 'n/a', inline = true },
        },
        timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ')
      }
    }
  })

  if Config.DropOnDetect then
    DropPlayer(src, Config.DropMessage or 'Disconnected')
  end
end)

-- Admin/test command: manually trigger a detection for yourself
RegisterCommand('antidumptest', function(source)
  local src = source
  if src == 0 then
    print('Run this in-game as a player.')
    return
  end
  TriggerClientEvent('chat:addMessage', src, { args = { 'AntiDump', 'Triggering test detection...' } })
  TriggerEvent('antidump:detected', { reason = 'manual_test' })
end)
