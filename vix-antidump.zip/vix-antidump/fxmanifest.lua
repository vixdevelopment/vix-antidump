fx_version 'cerulean'
games { 'gta5' }

name 'antidump'
author 'Cascade (Windsurf)'
version '1.0.0'
description 'Standalone anti-dump and disconnect/logging'

lua54 'yes'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'
