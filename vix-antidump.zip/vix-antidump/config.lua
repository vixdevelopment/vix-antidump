-- AntiDump configuration

Config = {}

-- When true, detected players will be dropped immediately
Config.DropOnDetect = true

-- Message shown to the player when they are dropped
Config.DropMessage = "Disconnected: Anti-dump protection triggered."

-- Thresholds for suspicious activity within a rolling window (seconds)
Config.WindowSeconds = 3

-- Consider it suspicious if a client calls these natives this many times within the window
Config.Thresholds = {
  GetNumResources = 3,
  GetResourceByFindIndex = 30,
  GetResourceState = 50,
  GetResourceMetadata = 60,
  LoadResourceFile = 20,
}

-- Enable extra heuristics that look for tight loops executing many times per second
Config.EnableLoopHeuristic = true
-- Number of function calls in a single frame considered suspicious
Config.LoopCallSpike = 800

-- Optional Discord webhook to log detections. Leave empty to disable.
Config.DiscordWebhook = ""

-- Customize the log prefix
Config.LogPrefix = "[AntiDump]"
