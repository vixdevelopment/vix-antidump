local counters = {}
local lastReset = 0

local function now()
  return GetGameTimer() / 1000.0
end

local function resetWindow()
  counters = {}
  lastReset = now()
end

resetWindow()

local function incr(name)
  counters[name] = (counters[name] or 0) + 1
end

local function shouldFlag(name)
  local thresh = Config.Thresholds[name]
  if not thresh then return false end
  return (counters[name] or 0) >= thresh
end

local function formatStack()
  local lines = {}
  for i = 2, 10 do
    local info = debug.getinfo(i, "nSl")
    if not info then break end
    lines[#lines+1] = ("#%d %s:%s %s"):format(i-1, tostring(info.short_src), tostring(info.currentline), tostring(info.name or "?"))
  end
  return table.concat(lines, " | ")
end

local function report(reason, extra)
  TriggerServerEvent('antidump:detected', {
    reason = reason,
    extra = extra or {},
    stack = formatStack(),
    resource = GetCurrentResourceName(),
    ts = os.time(),
  })
end

-- Wrap a native with a counting shim
local function wrapNative(name)
  local original = _G[name]
  if type(original) ~= 'function' then return end

  _G[name] = function(...)
    -- rolling window logic
    if now() - lastReset >= (Config.WindowSeconds or 3) then
      resetWindow()
    end

    incr(name)
    if shouldFlag(name) then
      report('threshold:' .. name, { count = counters[name] })
    end

    return original(...)
  end
end

-- Natives commonly used during client-side resource enumeration/dumps
local targets = {
  'GetNumResources',
  'GetResourceByFindIndex',
  'GetResourceState',
  'GetResourceMetadata',
  'LoadResourceFile',
}

for _, n in ipairs(targets) do
  wrapNative(n)
end

-- Heuristic: detect very tight loops causing excessive function calls within a frame
if Config.EnableLoopHeuristic then
  Citizen.CreateThread(function()
    while true do
      local start = GetGameTimer()
      local calls = 0
      debug.sethook(function() calls = calls + 1 end, '', 0)
      Citizen.Wait(0) -- one frame
      debug.sethook()
      if calls >= (Config.LoopCallSpike or 800) then
        report('loop_spike', { calls = calls })
      end
      -- small wait to avoid overhead
      local elapsed = GetGameTimer() - start
      local sleep = math.max(100, 200 - elapsed)
      Citizen.Wait(sleep)
    end
  end)
end

-- Command to self-test client-side reporting
RegisterCommand('antidumptest_client', function()
  report('manual_test_client', { note = 'Triggered by /antidumptest_client' })
  print((Config.LogPrefix or '[AntiDump]') .. ' Client test event sent')
end, false)
